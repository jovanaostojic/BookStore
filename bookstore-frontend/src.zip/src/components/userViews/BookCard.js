import React from "react";
import BookImg from "../../img/book.png";

function BookCard({ book }) {
  return (
    <section className="books">
      <div className="container">
        <div className="row">
          <div className="col-lg-3 col-6">
            <div className="inner">
              <article key={book.bookId}>
                <img src={BookImg} className="img-fluid" alt="" />
                <h3>{book.title}</h3>
                <p>
                  {book.author.authorFirstName +
                    " " +
                    book.author.authorLastName}
                </p>
                <div className="price">
                  <p>RSD {book.bookPrice}</p>
                </div>
                <div className="btns">
                  <button>Kupi</button>
                </div>
              </article>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default BookCard;
