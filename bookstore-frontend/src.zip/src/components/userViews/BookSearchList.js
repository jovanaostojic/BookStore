import React, { useState } from "react";
import BookCard from "./BookCard";
import Pagination from "../Pagination";

function BookSearchList({ filteredBooks }) {
  //Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(4);
  const indexOfLast = currentPage * perPage;
  const indexofFirst = indexOfLast - perPage;
  const current = filteredBooks.slice(indexofFirst, indexOfLast);
  const total = filteredBooks.length;
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const filtered = current.map((book) => (
    <div className="container">
      <BookCard key={book.id} book={book} />
      <div className="d-flex justify-content-center">
        <Pagination perPage={perPage} total={total} paginate={paginate} />
      </div>
    </div>
  ));
  return <div>{filtered}</div>;
}

export default BookSearchList;
