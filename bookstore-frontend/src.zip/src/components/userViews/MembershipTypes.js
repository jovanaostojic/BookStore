import React, { useState, useEffect } from "react";
import axios from "axios";
import MembershipCardImg from "../../img/membership-card.png";

function MembershipTypes() {
  const url = "https://localhost:7178/api/MembershipType";
  const [membershipTypes, setMembershipTypes] = useState(null);

  useEffect(() => {
    axios
      .get(url)
      .then((response) => {
        setMembershipTypes(response.data);
      })
      .catch((error) => {
        console.log(error);
        alert(error);
      });
  }, [url]);

  if (membershipTypes) {
    return (
      <section className="books">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-6">
              <div className="inner">
                {membershipTypes.map((membershipType) => (
                  <article key={membershipType.membershipTypeId}>
                    <img src={MembershipCardImg} className="img-fluid" alt="" />
                    <h3>{membershipType.membershipName}</h3>
                    <p>
                      Trajanje u mesecima: <b>{membershipType.duration}</b>
                    </p>
                    <div class="price">
                      <p>RSD {membershipType.membershipPrice}</p>
                    </div>
                    <div className="btns">
                      <button>Dodaj u korpu</button>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
  return <div></div>;
}
export default MembershipTypes;
