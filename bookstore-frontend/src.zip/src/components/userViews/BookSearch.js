import React, { useState } from "react";
import BookSearchList from "./BookSearchList";

function BookSearch({ details }) {
  const [searchField, setSearchField] = useState("");

  const filteredBooks = details.filter((book) => {
    return (
      book.title.toLowerCase().includes(searchField.toLowerCase()) ||
      book.author.authorFirstName
        .toLowerCase()
        .includes(searchField.toLowerCase()) ||
      book.author.authorLastName
        .toLowerCase()
        .includes(searchField.toLowerCase())
    );
  });

  const handleChange = (e) => {
    setSearchField(e.target.value);
  };

  function searchList() {
    return <BookSearchList filteredBooks={filteredBooks} />;
  }

  return (
    <section>
      <br />
      <div className="search">
        <input
          className="center-block"
          placeholder="Pretraga knjiga"
          onChange={handleChange}
        />
      </div>
      {searchList()}
    </section>
  );
}

export default BookSearch;
