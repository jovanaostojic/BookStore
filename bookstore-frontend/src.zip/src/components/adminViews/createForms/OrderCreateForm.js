import React, { useState, useEffect } from "react";
export default function OrderCreateForm(props) {
  const initialFormData = Object.freeze({
    orderDate: "",
    total: "",
    orderPaymentStatus: "",
    userId: "",
  });

  const [users, setUsers] = useState([]);
  function getUsers() {
    const url = "https://localhost:7178/api/User";
    fetch(url, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((usersFromServer) => {
        setUsers(usersFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });
  }
  useEffect(() => {
    getUsers();
  }, []);

  const [formData, setFormData] = useState(initialFormData);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const orderToCreate = {
      orderDate: formData.orderDate,
      total: formData.total,
      orderPaymentStatus: formData.orderPaymentStatus,
      userId: formData.userId,
    };

    const url = "https://localhost:7178/api/Order";

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderToCreate),
    })
      //.then((response) => response.json())
      .then((responseFromServer) => {
        console.log(responseFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });

    props.onOrderCreated(orderToCreate);
  };

  return (
    <div>
      <form className="login-reg">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center">
            <div className="col-lg-9">
              <div className="row d-flex justify-content-center align-items-center">
                <div className="col-lg-6">
                  <div className="reg">
                    <h3>Dodavanje nove porudžbine</h3>
                    <input
                      value={formData.orderDate}
                      name="orderDate"
                      type="date"
                      placeholder="Datum poručivanja"
                      onChange={handleChange}
                    />
                    <input
                      value={formData.total}
                      name="total"
                      type="number"
                      placeholder="Ukupno za plaćanje"
                      onChange={handleChange}
                    />
                    <input
                      value={formData.orderPaymentStatus}
                      name="orderPaymentStatus"
                      type="text"
                      placeholder="Status plaćanja"
                      onChange={handleChange}
                    />
                    <select name="userId" onChange={handleChange}>
                      <option value="">Odaberite korisnika</option>
                      {users.map((user) => (
                        <option key={user.id} value={user.id}>
                          {user.userName}
                        </option>
                      ))}
                    </select>
                    <button onClick={handleSubmit}>Dodaj</button>
                    <br />
                    <button onClick={() => props.onOrderCreated(null)}>
                      Odustani
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
