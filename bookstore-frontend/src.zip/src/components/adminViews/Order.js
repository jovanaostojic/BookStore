import React, { useState, useEffect } from "react";
import OrderCreateForm from "./createForms/OrderCreateForm";
import OrderUpdateForm from "./updateForms/OrderUpdateForm";
import Pagination from "../Pagination";
import sortIcon from "../../img/sort.png";

function Order() {
  const [orders, setOrders] = useState([]);
  const [showingCreateNewOrderForm, setShowingCreateNewOrderForm] =
    useState(false);
  const [orderCurrentlyBeingUpdated, setOrderCurrentlyBeingUpdated] =
    useState(null);

  const url = "https://localhost:7178/api/Order";

  function getOrders() {
    fetch(url, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((ordersFromServer) => {
        setOrders(ordersFromServer);
        console.log(ordersFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });
  }

  function deleteOrder(orderId) {
    const deleteURL = url + "/" + orderId;
    fetch(deleteURL, {
      method: "DELETE",
    })
      .then((response) => response.json())
      .then((responseFromServer) => {
        console.log(responseFromServer);
        onOrderDeleted(orderId);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });

    window.location.reload();
  }

  useEffect(() => {
    getOrders();
  }, []);

  //Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(5);
  const indexOfLast = currentPage * perPage;
  const indexofFirst = indexOfLast - perPage;
  const current = orders.slice(indexofFirst, indexOfLast);
  const total = orders.length;
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  //Sorting
  const [sortOrder, setSortOrder] = useState("ASC");
  const sorting = (col) => {
    if (sortOrder === "ASC") {
      const sorted = [...orders].sort((a, b) =>
        a[col].toLowerCase() > b[col].toLowerCase() ? 1 : -1
      );
      setOrders(sorted);
      setSortOrder("DSC");
    }
    if (sortOrder === "DSC") {
      const sorted = [...orders].sort((a, b) =>
        a[col].toLowerCase() < b[col].toLowerCase() ? 1 : -1
      );
      setOrders(sorted);
      setSortOrder("ASC");
    }
  };
  const sortingNumbers = (col) => {
    if (sortOrder === "ASC") {
      const sorted = [...orders].sort((a, b) => (a[col] > b[col] ? 1 : -1));
      setOrders(sorted);
      setSortOrder("DSC");
    }
    if (sortOrder === "DSC") {
      const sorted = [...orders].sort((a, b) =>
        a[col] < b[col].toLowerCase() ? 1 : -1
      );
      setOrders(sorted);
      setSortOrder("ASC");
    }
  };

  return (
    <section className="add-new">
      {showingCreateNewOrderForm === false &&
        orderCurrentlyBeingUpdated === null && (
          <div>
            <button onClick={() => setShowingCreateNewOrderForm(true)}>
              Dodaj novu porudžbinu
            </button>
          </div>
        )}
      {orders.length > 0 &&
        showingCreateNewOrderForm === false &&
        orderCurrentlyBeingUpdated === null &&
        renderOrdersTable()}

      {showingCreateNewOrderForm && (
        <OrderCreateForm onOrderCreated={onOrderCreated} />
      )}

      {orderCurrentlyBeingUpdated !== null && (
        <OrderUpdateForm
          order={orderCurrentlyBeingUpdated}
          onOrderUpdated={onOrderUpdated}
        />
      )}
    </section>
  );

  function renderOrdersTable() {
    return (
      <section className="table">
        <div className="container">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" onClick={() => sorting("orderId")}>
                  ID
                  <img src={sortIcon} />
                </th>
                <th scope="col" onClick={() => sorting("orderDate")}>
                  Datum porudžbine
                </th>
                <th scope="col" onClick={() => sortingNumbers("total")}>
                  Ukupan iznos
                </th>
                <th scope="col" onClick={() => sorting("orderPaymentStatus")}>
                  Status plaćanja
                </th>
                <th scope="col">Korisnik</th>
                <th scope="col">Akcije</th>
              </tr>
            </thead>
            <tbody>
              {current.map((order) => (
                <tr key={order.orderId}>
                  <th scope="row">{order.orderId}</th>
                  <td>{order.orderDate}</td>
                  <td>{order.total}</td>
                  <td>{order.orderPaymentStatus}</td>
                  <td>{order.user.userName}</td>
                  <td>
                    <ul>
                      <li className="edit">
                        <button
                          onClick={() => setOrderCurrentlyBeingUpdated(order)}
                        >
                          izmeni
                        </button>
                      </li>
                      <li className="delete">
                        <button
                          onClick={() => {
                            if (window.confirm("Da li ste sigurni?"))
                              deleteOrder(order.orderId);
                          }}
                        >
                          obriši
                        </button>
                      </li>
                    </ul>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <Pagination perPage={perPage} total={total} paginate={paginate} />
        </div>
      </section>
    );
  }

  function onOrderCreated(createdOrder) {
    setShowingCreateNewOrderForm(false);
    if (createdOrder === null) {
      return;
    }

    window.location.reload();
  }

  function onOrderUpdated(updatedOrder) {
    setOrderCurrentlyBeingUpdated(null);

    if (updatedOrder === null) {
      return;
    }

    let ordersCopy = [...orders];
    const index = ordersCopy.findIndex((ordersCopyOrder) => {
      if (ordersCopyOrder.orderId === updatedOrder.orderId) {
        return true;
      }
    });

    if (index !== -1) {
      ordersCopy[index] = updatedOrder;
    }

    setOrders(ordersCopy);
  }

  function onOrderDeleted(deletedOrderId) {
    let ordersCopy = [...orders];

    const index = ordersCopy.findIndex((ordersCopyOrder) => {
      if (ordersCopyOrder.orderId === deletedOrderId) {
        return true;
      }
    });

    if (index !== -1) {
      ordersCopy.splice(index, 1);
    }

    setOrders(ordersCopy);
  }
}
export default Order;
