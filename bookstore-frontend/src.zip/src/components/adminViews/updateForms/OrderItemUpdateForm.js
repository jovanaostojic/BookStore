import React, { useState, useEffect } from "react";
export default function OrderItemUpdateForm(props) {
  const initialFormData = Object.freeze({
    orderItemId: props.orderItem.orderItemId,
    orderId: props.orderItem.orderId,
    bookId: props.orderItem.bookId,
  });

  const [orders, setOrders] = useState([]);
  function getOrders() {
    const url = "https://localhost:7178/api/Order";
    fetch(url, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((ordersFromServer) => {
        setOrders(ordersFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });
  }
  useEffect(() => {
    getOrders();
  }, []);

  const [books, setBooks] = useState([]);
  function getBooks() {
    const url = "https://localhost:7178/api/Book";
    fetch(url, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((booksFromServer) => {
        setBooks(booksFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });
  }
  useEffect(() => {
    getBooks();
  }, []);

  const [formData, setFormData] = useState(initialFormData);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const orderItemToUpdate = {
      orderItemId: props.orderItem.orderItemId,
      orderId: formData.orderId,
      bookId: formData.bookId,
    };

    const url =
      "https://localhost:7178/api/OrderItem" +
      "/" +
      props.orderItem.orderItemId;

    fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderItemToUpdate),
    })
      //.then((response) => response.json())
      .then((responseFromServer) => {
        console.log(responseFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });

    props.onOrderItemUpdated(orderItemToUpdate);
  };

  return (
    <div>
      <form className="login-reg">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center">
            <div className="col-lg-9">
              <div className="row d-flex justify-content-center align-items-center">
                <div className="col-lg-6">
                  <div className="reg">
                    <h3>Izmena države</h3>
                    <input
                      value={formData.orderItemId}
                      name="orderItemId"
                      type="text"
                      placeholder="Id"
                      onChange={handleChange}
                      disabled
                    />
                    <select name="orderId" onChange={handleChange}>
                      <option value="">Odaberite porudžbinu</option>
                      {orders.map((order) => (
                        <option key={order.orderId} value={order.orderId}>
                          {order.orderId}
                        </option>
                      ))}
                    </select>
                    <select name="bookId" onChange={handleChange}>
                      <option value="">Odaberite knjigu</option>
                      {books.map((book) => (
                        <option key={book.bookId} value={book.bookId}>
                          {book.title}
                        </option>
                      ))}
                    </select>
                    <button onClick={handleSubmit}>Izmeni</button>
                    <br />
                    <button onClick={() => props.onOrderItemUpdated(null)}>
                      Odustani
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
