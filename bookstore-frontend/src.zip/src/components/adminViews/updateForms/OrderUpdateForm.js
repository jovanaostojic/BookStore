import React, { useState, useEffect } from "react";
export default function OrderUpdateForm(props) {
  const initialFormData = Object.freeze({
    orderId: props.order.orderId,
    orderDate: props.order.orderDate,
    total: props.order.total,
    orderPaymentStatus: props.order.orderPaymentStatus,
    userId: props.order.userId,
  });

  const [users, setUsers] = useState([]);
  function getUsers() {
    const url = "https://localhost:7178/api/User";
    fetch(url, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((usersFromServer) => {
        setUsers(usersFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });
  }
  useEffect(() => {
    getUsers();
  }, []);

  const [formData, setFormData] = useState(initialFormData);
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const orderToUpdate = {
      orderId: props.order.orderId,
      orderDate: formData.orderDate,
      total: formData.total,
      orderPaymentStatus: formData.orderPaymentStatus,
      userId: formData.userId,
    };

    const url = "https://localhost:7178/api/Order" + "/" + props.order.orderId;

    fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderToUpdate),
    })
      //.then((response) => response.json())
      .then((responseFromServer) => {
        console.log(responseFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });

    props.onOrderUpdated(orderToUpdate);
  };

  return (
    <div>
      <form className="login-reg">
        <div className="container">
          <div className="row d-flex justify-content-center align-items-center">
            <div className="col-lg-9">
              <div className="row d-flex justify-content-center align-items-center">
                <div className="col-lg-6">
                  <div className="reg">
                    <h3>Izmena porudžbine</h3>
                    <input
                      value={formData.orderId}
                      name="orderId"
                      type="text"
                      placeholder="Id"
                      onChange={handleChange}
                      disabled
                    />
                    <input
                      value={formData.orderDate}
                      name="orderDate"
                      type="date"
                      placeholder="Datum poručivanja"
                      onChange={handleChange}
                    />
                    <input
                      value={formData.total}
                      name="total"
                      type="number"
                      placeholder="Ukupno za plaćanje"
                      onChange={handleChange}
                    />
                    <input
                      value={formData.orderPaymentStatus}
                      name="orderPaymentStatus"
                      type="text"
                      placeholder="Status plaćanja"
                      onChange={handleChange}
                    />
                    <select name="userId" onChange={handleChange}>
                      <option value="">Odaberite korisnika</option>
                      {users.map((user) => (
                        <option key={user.id} value={user.id}>
                          {user.userName}
                        </option>
                      ))}
                    </select>
                    <button onClick={handleSubmit}>Izmeni</button>
                    <br />
                    <button onClick={() => props.onOrderUpdated(null)}>
                      Odustani
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
