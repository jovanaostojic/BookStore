import React, { useState, useEffect } from "react";
import OrderItemCreateForm from "./createForms/OrderItemCreateForm";
import OrderItemUpdateForm from "./updateForms/OrderItemUpdateForm";
import Pagination from "../Pagination";
import sortIcon from "../../img/sort.png";

function OrderItem() {
  const [orderItems, setOrderItems] = useState([]);
  const [showingCreateNewOrderItemForm, setShowingCreateNewOrderItemForm] =
    useState(false);
  const [orderItemCurrentlyBeingUpdated, setOrderItemCurrentlyBeingUpdated] =
    useState(null);

  const url = "https://localhost:7178/api/OrderItem";

  function getOrderItems() {
    fetch(url, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((orderItemsFromServer) => {
        setOrderItems(orderItemsFromServer);
        console.log(orderItemsFromServer);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });
  }

  function deleteOrderItem(orderItemId) {
    const deleteURL = url + "/" + orderItemId;
    fetch(deleteURL, {
      method: "DELETE",
    })
      .then((response) => response.json())
      .then((responseFromServer) => {
        console.log(responseFromServer);
        onOrderItemDeleted(orderItemId);
      })
      .catch((error) => {
        console.log(error);
        //alert(error);
      });

    window.location.reload();
  }

  useEffect(() => {
    getOrderItems();
  }, []);

  //Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(5);
  const indexOfLast = currentPage * perPage;
  const indexofFirst = indexOfLast - perPage;
  const current = orderItems.slice(indexofFirst, indexOfLast);
  const total = orderItems.length;
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  //Sorting
  const [sortOrder, setSortOrder] = useState("ASC");
  const sorting = (col) => {
    if (sortOrder === "ASC") {
      const sorted = [...orderItems].sort((a, b) =>
        a[col].toLowerCase() > b[col].toLowerCase() ? 1 : -1
      );
      setOrderItems(sorted);
      setSortOrder("DSC");
    }
    if (sortOrder === "DSC") {
      const sorted = [...orderItems].sort((a, b) =>
        a[col].toLowerCase() < b[col].toLowerCase() ? 1 : -1
      );
      setOrderItems(sorted);
      setSortOrder("ASC");
    }
  };

  return (
    <section className="add-new">
      {showingCreateNewOrderItemForm === false &&
        orderItemCurrentlyBeingUpdated === null && (
          <div>
            <button onClick={() => setShowingCreateNewOrderItemForm(true)}>
              Dodaj novu stavku porudžbine
            </button>
          </div>
        )}
      {orderItems.length > 0 &&
        showingCreateNewOrderItemForm === false &&
        orderItemCurrentlyBeingUpdated === null &&
        renderOrderItemsTable()}

      {showingCreateNewOrderItemForm && (
        <OrderItemCreateForm onOrderItemCreated={onOrderItemCreated} />
      )}

      {orderItemCurrentlyBeingUpdated !== null && (
        <OrderItemUpdateForm
          orderItem={orderItemCurrentlyBeingUpdated}
          onOrderItemUpdated={onOrderItemUpdated}
        />
      )}
    </section>
  );

  function renderOrderItemsTable() {
    return (
      <section className="table">
        <div className="container">
          <table className="table">
            <thead>
              <tr>
                <th scope="col" onClick={() => sorting("orderItemId")}>
                  ID
                  <img src={sortIcon} />
                </th>
                <th scope="col">Order ID</th>
                <th scope="col">Knjiga</th>
                <th scope="col">Akcije</th>
              </tr>
            </thead>
            <tbody>
              {current.map((orderItem) => (
                <tr key={orderItem.orderItemId}>
                  <th scope="row">{orderItem.orderItemId}</th>
                  <td>{orderItem.order.orderId}</td>
                  <td>{orderItem.book.title}</td>
                  <td>
                    <ul>
                      <li className="edit">
                        <button
                          onClick={() =>
                            setOrderItemCurrentlyBeingUpdated(orderItem)
                          }
                        >
                          izmeni
                        </button>
                      </li>
                      <li className="delete">
                        <button
                          onClick={() => {
                            if (window.confirm("Da li ste sigurni?"))
                              deleteOrderItem(orderItem.orderItemId);
                          }}
                        >
                          obriši
                        </button>
                      </li>
                    </ul>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <Pagination perPage={perPage} total={total} paginate={paginate} />
        </div>
      </section>
    );
  }

  function onOrderItemCreated(createdOrderItem) {
    setShowingCreateNewOrderItemForm(false);
    if (createdOrderItem === null) {
      return;
    }

    window.location.reload();
  }

  function onOrderItemUpdated(updatedOrderItem) {
    setOrderItemCurrentlyBeingUpdated(null);

    if (updatedOrderItem === null) {
      return;
    }

    let orderItemsCopy = [...orderItems];
    const index = orderItemsCopy.findIndex((orderItemsCopyOrderItem) => {
      if (
        orderItemsCopyOrderItem.orderItemId === updatedOrderItem.orderItemId
      ) {
        return true;
      }
    });

    if (index !== -1) {
      orderItemsCopy[index] = updatedOrderItem;
    }

    setOrderItems(orderItemsCopy);
  }

  function onOrderItemDeleted(deletedOrderItemId) {
    let orderItemsCopy = [...orderItems];

    const index = orderItemsCopy.findIndex((orderItemsCopyOrderItem) => {
      if (orderItemsCopyOrderItem.orderItemId === deletedOrderItemId) {
        return true;
      }
    });

    if (index !== -1) {
      orderItemsCopy.splice(index, 1);
    }

    setOrderItems(orderItemsCopy);
  }
}
export default OrderItem;
